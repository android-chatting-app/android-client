package com.example.ahn.loginclient;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Message;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.os.Handler;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ChatActivity extends AppCompatActivity {

    ListView m_ListView;
    CustomAdapter m_Adapter;
    String id = null;
    boolean lock = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        Intent intent = getIntent();
        id = intent.getExtras().getString("id");
        Button send = (Button)findViewById(R.id.button2);

        // 커스텀 어댑터 생성
        m_Adapter = new CustomAdapter();

        // Xml에서 추가한 ListView 연결
        m_ListView = (ListView) findViewById(R.id.listView1);

        // ListView에 어댑터 연결
        m_ListView.setAdapter(m_Adapter);

        //m_Adapter.add(id+" 님이 입장하셨습니다.",2);

        Thread thread = new Thread(new Runnable() {
            OkHttpClient client = new OkHttpClient();
            @Override
            public void run() {
                while(true) {
                    SystemClock.sleep(1000);
                    //lock();
                    Request request = new Request.Builder().url("http://175.115.185.16:8080/LoginWebServer/GetData?act=syn&id=" + id).build();
                    try {
                        Response response = client.newCall(request).execute();
                        String newChat = response.body().string();
                        //unlock();
                        if(!newChat.equals("null") && newChat!=null && !newChat.isEmpty()) {
                            Bundle data = new Bundle();
                            data.putString("data", newChat);
                            Message msg = Message.obtain();
                            msg.setData(data);
                            handler.sendMessage(msg);
                        }
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
            private Handler handler = new Handler() {
                public void handleMessage(Message msg) {
                    String hchat = msg.getData().getString("data");
                    refresh(hchat, 0);
                }
            };
        });
        thread.start();


        send.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editText = (EditText) findViewById(R.id.editText1);
                String inputValue = editText.getText().toString();
                editText.setText("");
                refresh(inputValue, 1);

                inputValue = id + ": " + inputValue;
                new AsyncTask<String, Void, Void>() {
                    @Override
                    protected Void doInBackground(String... params) {
                        String chat = params[0];
                        OkHttpClient client = new OkHttpClient();
                        //lock();
                        Request request = new Request.Builder().url("http://175.115.185.16:8080/LoginWebServer/GetData?act=send&chat=" + chat).build();
                        try {
                            client.newCall(request).execute();
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                        //unlock();
                        return null;
                    }
                }.execute(inputValue);
            }
        });

    }

    private void refresh (String inputValue, int _str) {
        m_Adapter.add(inputValue, _str) ;
        m_Adapter.notifyDataSetChanged();
    }

    private void lock(){while(lock){}lock=true;}
    private void unlock(){lock=false;}
}